#!/usr/bin/env python3
"""Cron Retenção — toda segunda 8h — top 10 em risco no Telegram privado"""
import sys, os
sys.path.insert(0, '/opt/automacoes/jactos/cobranca')
os.chdir('/opt/automacoes/jactos/cobranca')
from datetime import datetime, timezone, timedelta
TZ_BR = timezone(timedelta(hours=-3))
def now_br(): return datetime.now(TZ_BR)
def log(msg): print(f"[{now_br().strftime('%d/%m/%Y %H:%M:%S')}] {msg}", flush=True)
import requests
from app.dashboards.cobranca.service_retencao import get_retencao, get_kpis_retencao

from app.core.telegram import telegram_url, TELEGRAM_CHATS_PRIVADOS

def telegram(msg):
    for chat in TELEGRAM_CHATS_PRIVADOS:
        try:
            requests.post(telegram_url(),
                data={"chat_id": chat, "text": msg, "parse_mode": "HTML"}, timeout=10)
        except Exception as e:
            log(f"[TELEGRAM ERRO] {e}")

def main():
    log("=== RELATÓRIO RETENÇÃO ===")
    rows, total = get_retencao(pagina=1, por_pagina=15, score_min=35)
    kpis = get_kpis_retencao()

    linhas = [
        "🛡️ <b>RELATÓRIO DE RETENÇÃO</b>",
        f"📅 {now_br().strftime('%d/%m/%Y')} | {kpis['total']} clientes monitorados",
        f"🔴 Críticos: {kpis['criticos']} | 🟡 Atenção: {kpis['atencao']}",
        f"💸 Valor em risco: R$ {kpis['valor']:.2f}",
        "",
        "<b>🔝 Top clientes em risco:</b>",
    ]
    for r in rows[:10]:
        nivel = "🔴" if r["nivel"]=="critico" else "🟡"
        linhas.append(
            f"  {nivel} <b>{r['razao']}</b> — "
            f"score {r['score']} | {r['dias_atraso']}d atraso | "
            f"{r['total_pagas']} parcelas"
        )

    linhas.append(f"\n<i>IaTechHub · {now_br().strftime('%d/%m/%Y %H:%M')}</i>")
    telegram("\n".join(linhas))
    log(f"Relatório enviado — {len(rows)} clientes")

if __name__ == "__main__":
    main()
